// ===========================================
//  Funções Utilitárias
// ===========================================

// Máximo Divisor Comum
function mdc(a, b) {
    return b ? mdc(b, a % b) : Math.abs(a);
}

// Lê números e trata fração "a/b"
function parseNumero(str) {
    str = String(str);
    if (str.includes("/")) {
        let partes = str.split("/");
        return parseFloat(partes[0]) / parseFloat(partes[1]);
    }
    return parseFloat(str);
}

// Transforma número real em fração simples
function formatarFracao(num) {
    let tol = 1e-6;
    if (Math.abs(Math.round(num) - num) < tol)
        return String(Math.round(num));

    for (let d = 1; d <= 1000; d++) {
        let n = Math.round(num * d);
        if (Math.abs(num - n / d) < tol) {
            let m = mdc(n, d);
            return `${n / m}/${d / m}`;
        }
    }
    return num.toFixed(4);
}

// ===========================================
//  Parsing de Polinômios para JS
// ===========================================

function parsePolinomio(expr) {
    let s = String(expr).replace(/\s+/g, "");
    s = s.replace(/X/g, "x");
    s = s.replace(/([0-9\)])x/g, "$1*x");
    s = s.replace(/x([0-9\(])/g, "x*$1");
    s = s.replace(/\^/g, "**");
    return s;
}

function criarPolinomio(expr) {
    let jsExpr = parsePolinomio(expr);
    return new Function("x", `return (${jsExpr});`);
}

function avaliarExpressao(expr, x) {
    let f = criarPolinomio(expr);
    return Number(f(x));
}

// ===========================================
//  Derivação simbólica
// ===========================================

function derivarPolinomio(polinomioStr) {
    polinomioStr = String(polinomioStr);
    let derivada = [];

    for (let i = 0; i < polinomioStr.length; i++) {
        if (polinomioStr[i] === "+" || polinomioStr[i] === "-") continue;

        let posX = polinomioStr.indexOf("x", i);

        // Constante → derivada = 0
        if (posX === -1 || posX > i + 6) {
            let termoConst = "";
            let k = 0;

            while (i + k < polinomioStr.length &&
                   (polinomioStr[i + k] === "/" || !isNaN(parseInt(polinomioStr[i + k])))) {
                termoConst += polinomioStr[i + k];
                k++;
            }

            if (termoConst !== "") {
                i += k - 1;
                continue;
            }
        }

        if (polinomioStr[i] === "x") {
            let coef = [];
            let sinal = 1;
            let j = i - 1;

            while (j >= 0 && (polinomioStr[j] === "/" || !isNaN(parseInt(polinomioStr[j])))) {
                coef.unshift(polinomioStr[j]);
                j--;
            }
            if (j >= 0 && polinomioStr[j] === "-") sinal = -1;

            let coefStr = coef.join("");
            let coefVal = coefStr === "" ? 1 : parseNumero(coefStr);
            coefVal *= sinal;

            let expoente = 1;
            let pos = i + 1;

            if (pos < polinomioStr.length && polinomioStr[pos] === "^") {
                pos++;
                let pot = [];
                while (pos < polinomioStr.length &&
                       (polinomioStr[pos] === "-" || polinomioStr[pos] === "/" || !isNaN(parseInt(polinomioStr[pos])))) {
                    pot.push(polinomioStr[pos]);
                    pos++;
                }
                expoente = parseNumero(pot.join(""));
                i = pos - 1;
            }

            let novoCoef = coefVal * expoente;
            let novaPot = expoente - 1;

            if (Math.abs(novoCoef) > 1e-9) {
                let coefFmt = formatarFracao(novoCoef);
                let potFmt = formatarFracao(novaPot);

                if (derivada.length > 0 && novoCoef > 0)
                    derivada.push("+");

                if (Math.abs(novaPot) > 1e-9) {
                    let coefUm = Math.abs(novoCoef - 1) < 1e-9;
                    let coefMenosUm = Math.abs(novoCoef + 1) < 1e-9;

                    if (!coefUm && !coefMenosUm) derivada.push(coefFmt);
                    else if (coefMenosUm) derivada.push("-");

                    derivada.push("x");

                    if (Math.abs(novaPot - 1) > 1e-9) {
                        derivada.push("^");
                        derivada.push(potFmt);
                    }
                } else {
                    derivada.push(coefFmt);
                }
            }
        }
    }

    let out = derivada.join("")
        .replace(/\+\-/g, "-")
        .replace(/\-\-/g, "+")
        .replace(/x\^1/g, "x");

    if (out.startsWith("+")) out = out.substring(1);
    if (out === "" || out === "+" || out === "-") return "0";

    return out;
}

// ===========================================
//  Integral simbólica
// ===========================================

function integral(expr) {
    let elementos = separarElementos(expr);
    let resolvidos = integrarCadaElemento(elementos);

    let resultado = "";

    for (let i = 0; i < resolvidos.length; i++) {
        if (i === 0) {
            if (resolvidos[i][0] === "-")
                resultado = "- " + resolvidos[i].replace("-", "");
            else
                resultado = resolvidos[i];
        } else {
            if (resolvidos[i].includes("-"))
                resultado += " - " + resolvidos[i].replace("-", "");
            else
                resultado += " + " + resolvidos[i].replace("+", "");
        }
    }

    return resultado + " + C";
}

function separarElementos(expr) {
    expr = expr.replace(/\s+/g, "");
    expr = expr.replace("(-", "-(");

    let elementos = [];
    let sinais = ["+", "-"];
    let inicio = 0;

    for (let i = 0; i < expr.length; i++) {
        let ultimo = i === expr.length - 1;

        if ((sinais.includes(expr[i]) && expr[i - 1] !== "^" && i !== 0) || ultimo) {
            let termo = ultimo ? expr.substring(inicio) : expr.substring(inicio, i);
            elementos.push(ajustarPotenciaInvisivel(termo));
            inicio = i;
        }
    }
    return elementos;
}

function ajustarPotenciaInvisivel(t) {
    if (t.includes("x") && !t.includes("^"))
        return t + "^1";
    return t;
}

function tipoIntegral(t) {
    let ehFracao = false;

    if (t.includes("x")) {
        let ateX = t.substring(0, t.indexOf("x"));
        if (ateX.includes("/")) ehFracao = true;
    } else if (t.includes("/")) ehFracao = true;

    if (!isNaN(t)) return 1;
    if (t.includes("^") && !ehFracao) return 2;
    if (ehFracao && t.includes("x")) return 3;
    if (ehFracao) return 4;

    return -1;
}

function integrarCadaElemento(lista) {
    for (let i = 0; i < lista.length; i++) {
        let tipo = tipoIntegral(lista[i]);

        if (tipo === 1) {
            let num = parseInt(lista[i]);
            lista[i] = num + "x";
        }

        else if (tipo === 2) {
            if (lista[i].includes("^")) {
                let indexPot = lista[i].indexOf("^");
                let potStr = lista[i].substring(indexPot + 1);
                let baseStr = lista[i].substring(0, indexPot);
                let base = parseInt(baseStr);

                if (parseInt(potStr) === -1) {
                    lista[i] = isNaN(base) ? "ln|x|" : base + "ln|x|";
                    continue;
                }

                if (baseStr === "x" || baseStr === "+x") base = 1;
                if (baseStr === "-x") base = -1;

                let n = parseInt(potStr);
                let novoN = n + 1;

                if (base % novoN === 0) {
                    let novoCoef = base / novoN;
                    lista[i] = (novoCoef === 1 ? "" : novoCoef) + "x^" + novoN;
                } else {
                    let m = mdc(base, novoN);
                    lista[i] = "(" + base/m + "/" + novoN/m + ")x^" + novoN;
                }
            }

            else {
                let idx = lista[i].indexOf("x");
                let base = parseInt(lista[i].substring(0, idx));
                lista[i] = (base/2) + "x^2";
            }
        }

        else if (tipo === 3) {
            let t = lista[i].replace(/\(|\)/g, "");
            let idxBarra = t.indexOf("/");
            let idxX = t.indexOf("x");
            let idxPot = t.indexOf("^");

            let num = parseInt(t.substring(0, idxBarra));
            let den = parseInt(t.substring(idxBarra+1, idxX));
            let pot = parseInt(t.substring(idxPot+1));

            if (pot === -1) {
                lista[i] = "(" + num + "/" + den + ")ln|x|";
                continue;
            }

            let novoN = pot + 1;
            let novoDen = den * novoN;
            let m = mdc(num, novoDen);

            lista[i] = "(" + (num/m) + "/" + (novoDen/m) + ")x^" + novoN;
        }

        else if (tipo === 4) {
            let t = lista[i].replace(/\(|\)/g, "");
            lista[i] = "(" + t + ")x";
        }

        else {
            throw "Tipo de integral não reconhecido: " + lista[i];
        }
    }

    return lista;
}

// ===========================================
//  Newton–Cotes: Regra do Trapézio
// ===========================================

function trapezio(expr, a, b, n) {
    let A = parseFloat(a);
    let B = parseFloat(b);
    let N = parseInt(n, 10);

    if (isNaN(A) || isNaN(B) || isNaN(N) || N <= 0)
        throw new Error("Parâmetros inválidos para trapezio");

    let f = criarPolinomio(expr);
    let h = (B - A) / N;

    let s = f(A) + f(B);

    for (let i = 1; i < N; i++) {
        let x = A + i*h;
        s += 2 * f(x);
    }

    return (h/2) * s;
}

function browserNewtonCotes(expr, a, b, n) {
    try {
        return trapezio(expr, a, b, n);
    } catch(e) {
        return "Erro: " + e.message;
    }
}


// ===========================================
//  Pontos Críticos
// ===========================================

function acharPC(expr, a, b, tol = 1e-6) {

    let d = derivarPolinomio(expr);
    let df = criarPolinomio(d);

    let roots = [];
    tol = parseFloat(tol);

    // Varredura inicial para detectar mudança de sinal
    let passos = 200;
    let h = (b - a) / passos;

    let x1 = a;
    let y1 = df(x1);

    for (let i = 1; i <= passos; i++) {
        let x2 = a + i*h;
        let y2 = df(x2);

        if (y1 === 0) roots.push(x1);
        if (y1*y2 < 0) {
            roots.push(bissecao(df, x1, x2, tol));
        }

        x1 = x2;
        y1 = y2;
    }

    // Remove duplicados
    return [...new Set(roots.map(r => Number(r.toFixed(6))))];
}

function bissecao(f, a, b, tol) {
    let fa = f(a);
    let fb = f(b);

    if (fa * fb > 0) return null;

    let mid;
    while ((b - a) > tol) {
        mid = (a + b)/2;
        let fm = f(mid);

        if (fa * fm <= 0) {
            b = mid;
            fb = fm;
        } else {
            a = mid;
            fa = fm;
        }
    }
    return (a + b)/2;
}

// ===========================================
//  Execução em Node
// ===========================================

function rodarNode() {
    let prompt = require("prompt-sync")();

    console.log("=== CALCULADORA ===");

    while (true) {
        console.log("\n1 - Derivadas e Pontos Críticos");
        console.log("2 - Integral Simbólica");
        console.log("3 - Newton–Cotes (Trapézio)");
        console.log("0 - Sair");

        let op = prompt("Escolha: ");

        if (op === "0") break;

        if (op === "1") {
            let pol = prompt("Informe o polinômio: ");
            console.log("f'(x): " + derivarPolinomio(pol));
            console.log("f''(x): " + derivarPolinomio(derivarPolinomio(pol)));

            let a = parseFloat(prompt("a: "));
            let b = parseFloat(prompt("b: "));
            let tol = parseFloat(prompt("Tolerância: "));

            console.log("Pontos críticos:", acharPC(pol, a, b, tol));
        }

        else if (op === "2") {
            let eq = prompt("Expressão: ");
            console.log("Integral:", integral(eq));
        }

        else if (op === "3") {
            let eq = prompt("f(x): ");
            let a = parseFloat(prompt("a: "));
            let b = parseFloat(prompt("b: "));
            let n = parseInt(prompt("n: "));
            console.log("Resultado:", trapezio(eq, a, b, n));
        }
    }
}

// ===========================================
//  Exportação para Browser e Node
// ===========================================

(function detectAndExport() {
    if (typeof window === "undefined") {
        rodarNode();
    } else {
        window.derivarPolinomio = derivarPolinomio;
        window.integral = integral;
        window.acharPC = acharPC;
        window.trapezio = trapezio;
        window.browserNewtonCotes = browserNewtonCotes;
        window.avaliarExpressao = avaliarExpressao;
    }
})();
